<?php 
$id=uniqid();
$name=$_POST["name"];
$name1=$_POST["name1"];
$email=$_POST["email"];
$password=$_POST["pwd"];
$password1=$_POST["pwd1"];
$phone=$_POST["phone"];
$query='insert into `customer_details` values("'.$id.'","'.$name.'","'.$name1.'","'.$email.'","'.$password.'","'.$phone.'",0)';
echo $query;

$con=Mysql_connect("localhost","root","");

if(!$con){
	echo "not connected";
}
Mysql_select_db("meeratravels");
$result = mysql_query($query,$con);
if($result){
	session_start();
	$_SESSION['username'] = $email;
	$_SESSION['phone'] = $phone;
	$_SESSION['NumberVerified'] = 0;
	echo "<script>window.location='otp.php';</script>";

}
echo $result;
?>