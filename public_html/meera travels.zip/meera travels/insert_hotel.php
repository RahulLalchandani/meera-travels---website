<?php 
$id=uniqid();
$hname=$_POST["hname"];
$hlocation=$_POST["hlocation"];
$hrating=$_POST["hrating"];
//$himage=$_POST["himage"];
$hservices=$_POST["hservices"];
$hprice=$_POST["hprice"];
$hrooms=$_POST["hrooms"];
$hguests=$_POST["hguests"];
$query='insert into `hotels` values("'.$id.'","'.$hname.'","'.$hlocation.'","'.$hrating.'","","'.$hservices.'","'.$hprice.'","'.$hrooms.'","'.$hguests.'")';
echo $query;
$con=Mysql_connect("localhost","root","");
if(!$con){
	echo "not connected";
}
Mysql_select_db("meeratravels");
$result = mysql_query($query,$con);
echo $result;
?>