<?php
include("connection.php");
session_start();
$email=$_POST["email"];
$password=$_POST["pwd"];
echo $email;
echo $password;

$query='select * from customer_details where email="'.$email.'" AND password="'.$password.'"';
$result = mysql_query($query,$con);
//echo $result;
$count = mysql_num_rows($result);
if($count > 0){
	echo "vaild user";
	$_SESSION['username'] = $email;
	echo "<script>window.location='index.html';</script>";
}
else{
	//echo "invaild user";
}
?>